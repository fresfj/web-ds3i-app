import { createBrowserHistory } from 'history'

const history = createBrowserHistory({
    basename: '',
    forceRefresh: false
})

export { history }